package ListDay1;

import java.util.*;
public class Test 
{
	public static void main(String[] args) 
	{
		List<Integer> l = new ArrayList<>();
		l.add(10);
		l.add(20);
		l.add(30);
		l.add(40);
		
		System.out.println(l);
		int x = l.get(2);
		System.out.println(x);
		
	}

}
