package ListDay2;

public class Student 
{
	private int srollno;
	private String sname;
	private String saddr;
	
	public int getSrollno() 
	{
		return srollno;
	}
	
	public void setSrollno(int srollno)
	{
		this.srollno = srollno;
	}
	
	public String getSname()
	{
		return sname;
	}
	
	public void setSname(String sname)
	{
		this.sname = sname;
	}
	
	public String getSaddr() 
	{
		return saddr;
	}
	
	public void setSaddr(String saddr)
	{
		this.saddr = saddr;
	}
	
	

}
