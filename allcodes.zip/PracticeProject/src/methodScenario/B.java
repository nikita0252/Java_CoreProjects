package methodScenario;

public class B extends A{
	
		public void m2()
		{
			super.m2();
			System.out.println("m2-b");
		}
	}


