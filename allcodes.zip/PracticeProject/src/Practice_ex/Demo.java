package Practice_ex;

public class Demo 
{
	private int id;
	private A a;

}
