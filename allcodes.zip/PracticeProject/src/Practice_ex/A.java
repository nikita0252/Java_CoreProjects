package Practice_ex;

public class A 
{
	int x;
	public A m1()
	{
		A a = new A();
		a.x=20;
		
		return a;
	}

}
