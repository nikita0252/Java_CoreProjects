package DigitCount;

public class MobileValidation {
	public static void main(String args[])
	{
	  float a=12.12f;
	  String str = String.valueOf(a);
	  System.out.println(str);
	  System.out.println( str.length());
	  }
	}


