package DigitCount;

public class A {
	public static void main(String args[]) {
		
	
	int num =121;
	int count=0;
	
	
   while(num!=0)
	{
    	num=num/10;
    	count++;
	    	
	}
   System.out.println(count);
	}		
	}


//for(int i=no; i>0; i=no/10)
//while(no>0)
