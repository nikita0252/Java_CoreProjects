package Instance_Var_Ex;

public class Bank {
	
        int id;
        String name;
        String noofbranch;
        long mobno;
        String EmailId;
        
}


