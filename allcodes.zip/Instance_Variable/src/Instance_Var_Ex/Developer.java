package Instance_Var_Ex;

public class Developer {
	int id;
	String name;
	String projectname;
	float salary;
	char grade;
}
