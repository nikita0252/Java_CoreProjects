package Demo_Project;

public class Patient {
   int id;
   String name;
   String address;
   long mob_no;
   String disease;
}
