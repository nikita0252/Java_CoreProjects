package Demo_Project;

public class Bank {
             int id;
             String name;
             String noofbranch;
             long mobno;
             String EmailId;
             
}
