package Demo_Project;

public class TestPerson {

	 public static void main(String args[])
	 {
		 Person p = new Person();
		 p.Srno=101;
		 p.Name="abc";
		 p.address="Pune";
		 p.age=22;
		 p.weight=45;
		 p.height=165;
		 p.mobno=987834344l;
		 p.prof="student";
		 
		 System.out.println(p.Srno);
		 System.out.println(p.Name);
		 System.out.println(p.address);
		 System.out.println(p.age);
		 System.out.println(p.weight);
		 System.out.println(p.height);
		 System.out.println(p.mobno);
		 System.out.println(p.prof);
	 }
}
