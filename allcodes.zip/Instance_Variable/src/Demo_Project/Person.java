package Demo_Project;

public class Person {

	 int Srno;
	 String Name,address,prof;
	 int age,weight,height;
	 long mobno;
	 
	 
}
