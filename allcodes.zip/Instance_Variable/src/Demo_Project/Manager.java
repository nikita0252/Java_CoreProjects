package Demo_Project;

public class Manager {
	int id;
	String name;
	float salary;
	String quali;
	String bname;

}

