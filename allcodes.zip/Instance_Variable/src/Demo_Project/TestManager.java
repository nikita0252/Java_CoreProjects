package Demo_Project;

public class TestManager {
 
	 public static void main(String args[])
	 {
		 Manager m = new Manager();
		 m.id=101;
		 m.name="Abc";
		 m.salary=4588.09f;
		 m.quali="MCA";
		 m.bname="Computer";
		 
		 System.out.println(m.id);
		 System.out.println(m.name);
		 System.out.println(m.salary);
		 System.out.println(m.quali);
		 System.out.println(m.bname);
		 
		 
	 }
}
