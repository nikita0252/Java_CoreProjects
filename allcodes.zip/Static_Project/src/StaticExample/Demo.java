package StaticExample;

public class Demo 
{
	int a = 40;
		
		public static void main(String args[])
		{
			//
			Demo a1 = new Demo();
			System.out.println(a1.a);
		}
	

}
