package toString_Ex;

public class Demo1 
{
	public static void main(String args[])
	{
		Demo d = new Demo();
		d.setName("abc");
		d.setRollno(12);
	System.out.println(d);
	System.out.println(d.toString());
	System.out.println(d.hashCode());
	}

}
//1531448569