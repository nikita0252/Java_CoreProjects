package OverridetoStringClass;

public class A {
	

}
