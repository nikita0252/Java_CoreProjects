package OverridetoStringClass;

public class ATest {
	public static void main(String args[])
	{
		A a = new A();
		System.out.println(a);
		System.out.println(a.toString());
		System.out.println(a.hashCode());
		
	}
	

}
