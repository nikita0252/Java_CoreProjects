package Overriding_Ex;

public class B {
	public static void m1(String s)
	{
		//System.out.println(M1);
	}
	public final void m2(String s) {
		//System.out.println(M2);
	}

}
