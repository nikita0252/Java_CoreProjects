package Overriding_Ex;

public class A {
 public static void m1(String s)
 {
	 //System.out.println(M1);
}
 public final void m2()
 {
	 //System.out.println(M2);
 }
 public static final void m3()
 {
	 //System.out.println(M3);
 }
}
