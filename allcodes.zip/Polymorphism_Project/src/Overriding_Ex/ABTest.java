package Overriding_Ex;

public class ABTest {
 public static void main(String args[])
 {
	 A.m1("abc");
	 //A.m2();
	 B.m1("nikita");;
	 //B.m2();
	 
 }
}
