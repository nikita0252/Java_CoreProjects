package Overriding_Ex;

public class Hunter extends Bullet{
	@Override
	public void start()
	{
		System.out.println("Kick start");
		System.out.println("Button start");
	}

}
