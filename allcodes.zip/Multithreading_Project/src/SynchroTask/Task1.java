package SynchroTask;

public class Task1
{
	public synchronized void display(String msg)
	{
		System.out.println("[");
		System.out.println(msg);
		System.out.println("]");
		
		
	}

	

}
