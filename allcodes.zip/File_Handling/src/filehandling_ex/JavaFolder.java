package filehandling_ex;

public class JavaFolder 
{
	public static void main (String args[]) 
	{
		
	}

}
