package checkedException;

public class ABC {

}
