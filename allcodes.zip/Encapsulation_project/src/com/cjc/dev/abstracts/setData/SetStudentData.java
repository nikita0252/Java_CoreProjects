package com.cjc.dev.abstracts.setData;
import java.util.*;
import com.cjc.dev.interfaces.*;


public abstract class SetStudentData implements AllData2
	{
      Scanner sc = new Scanner(System.in);
	}

