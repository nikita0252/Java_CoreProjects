package com.cjc.dev.interfaces;

public interface AllData1 {
	public void setStudentData();
	public void setTeacherData();
	public void setSchoolData();

}
