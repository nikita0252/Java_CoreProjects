package com.cjc.dev.interfaces;

public interface AllData2 extends AllData1 {
   public void setCollegeData();
   public void setUniversityData();
   public void getAllData();
   
}
