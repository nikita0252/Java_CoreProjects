package com.cjc.dev.pojos;

public class Teacher {
 private int id;
 private long tmobno;
 private String tname;
 private char tbgroup;
 private boolean tstatus;
 private Student st;
}
