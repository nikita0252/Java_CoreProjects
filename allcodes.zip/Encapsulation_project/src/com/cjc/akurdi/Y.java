package com.cjc.akurdi;
import com.cjc.karvenagar.*;

public class Y {
 public void yy()
 {
	 A a = new A();
	 a.m1();
	 
 }
}
