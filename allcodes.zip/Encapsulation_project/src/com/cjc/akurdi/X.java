package com.cjc.akurdi;
import com.cjc.karvenagar.*;

public class X extends A {
	public void xx()
	{
		A a = new A();
		a.m1();
		
		X x = new X();
		x.m1();
		x.m4();
		
	}

}
