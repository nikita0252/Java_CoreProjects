package com.cjc.akurdi;
import com.cjc.karvenagar.*;

public class Z extends X {
	
		public void zz()
		{
			Z z = new Z();
			z.m1();
			z.m4();
			
			X x = new X();
			x.m1();
			
			A a = new A();
			a.m1();
		}
		public static void main(String args[])
		{
			
			
			
		}
	}


