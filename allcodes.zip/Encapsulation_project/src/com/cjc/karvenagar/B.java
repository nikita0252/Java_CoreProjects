package com.cjc.karvenagar;

public class B {
	public void bb()
	{
		A a = new A();
		a.m1();
		a.m2();
		a.m4();
	}

}
