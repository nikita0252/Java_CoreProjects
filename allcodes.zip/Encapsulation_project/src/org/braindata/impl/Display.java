package org.braindata.impl;
import org.braindata.model.*;
public class Display extends Student
{
	public void Studentfirst()
	{
		Display d= new Display();
		d.rollno=101;
		d.name="abc";
		d.mobileno=8393939339l;
		d.fees=89.98;
		d.address="Pune";
		d.clgname="CJC";
		
		System.out.println("Roll no :"+d.rollno);
		System.out.println("Name :"+d.name);
		System.out.println("Mobile No :"+d.mobileno);
		System.out.println("Fees :"+d.fees);
		System.out.println("Address :"+d.address);
		System.out.println("College Name :"+d.clgname);
				
	}
	public void StudentSecond()
	{
		Display d = new Display();
		d.rollno=102;
		d.name="pqr";
		d.mobileno=8393939339l;
		d.fees=92.98;
		d.address="Pune";
		d.clgname="CJC";
		
		System.out.println("Roll no :"+d.rollno);
		System.out.println("Name :"+d.name);
		System.out.println("Mobile No :"+d.mobileno);
		System.out.println("Fees :"+d.fees);
		System.out.println("Address :"+d.address);
		System.out.println("College Name :"+d.clgname);
				
	}
	
	
	

}
