package org.braindata.test;
import org.braindata.impl.*;

public class TesData extends Display {
	public static void main(String args[])
	{
		TesData td = new TesData();
		td.Studentfirst();
		td.StudentSecond();
	}
	

}
