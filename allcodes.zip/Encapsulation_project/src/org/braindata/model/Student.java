package org.braindata.model;

public class Student {
  protected int rollno;
  protected String name;
  protected long mobileno;
  protected double fees;
  protected String address;
  protected String clgname;
}
