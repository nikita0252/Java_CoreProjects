package ArrayTask;

public class Task2 
{

	public static void main(String[] args) 
	
	{
		
		String i[] = new String[3];
		i[0] = "abc";
		i[1] = "pqr";
		i[2] = "stu";
		
		for(int j =0; j<=i.length; j++)
		{
			System.out.println(i[j]);
		}
		
		
	
		
		
		
	}

}
