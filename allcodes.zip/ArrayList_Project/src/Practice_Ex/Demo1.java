package Practice_Ex;
import java.util.*;


public class Demo1 
{
	public static void main(String args[])
	{
		List<String> l = new ArrayList<>();
		l.add("sbi");
		l.add("tring");
		l.add("Sanskruti");
		
		
		l.removeIf(x-> x.startsWith("S"));
		l.removeIf(x -> x.contains("bi"));
	    System.out.println(l);
		
		
	}

}
