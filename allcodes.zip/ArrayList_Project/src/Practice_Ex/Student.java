package Practice_Ex;

public class Student 
{
	int sroll,smarks,sbatchno;
	String sname;
	public Student(int rollno,String name,int marks,int batchno)
	{
		sroll=rollno;
		sname=name;
		smarks=marks;
		sbatchno=batchno;
	}
	

}
