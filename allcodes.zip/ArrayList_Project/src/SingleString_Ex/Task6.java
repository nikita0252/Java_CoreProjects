package SingleString_Ex;
import java.util.*;

public class Task6 
{
	public static void main(String args[])
	{
		List<String> l = new ArrayList<>();
		l.add("aab");
		l.add("bba");
		l.add("cca");
		l.add("yys");
		
		
		
	}

}
  