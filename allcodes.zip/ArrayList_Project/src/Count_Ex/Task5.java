package Count_Ex;

import java.util.ArrayList;
import java.util.List;

public class Task5 
{
	public static void main(String args)
	{
      List<Integer> l = new ArrayList<>();
		
		l.add(23);
		l.add(10);
		l.add(4);
		l.add(5);
		
		int count = l.size();
		System.out.println(count);
		
	}

}
