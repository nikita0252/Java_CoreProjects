/**
 * 
 */
/**
 * 
 */
module CovarientRule_Inheritance {
}