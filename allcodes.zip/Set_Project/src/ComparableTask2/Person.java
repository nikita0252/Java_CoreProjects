package ComparableTask2;

public class Person 
{
	private String pname;
	private String paddr;
	private long pmob;
	
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPaddr() {
		return paddr;
	}
	public void setPaddr(String paddr) {
		this.paddr = paddr;
	}
	public long getPmob() {
		return pmob;
	}
	public void setPmob(long pmob) {
		this.pmob = pmob;
	}

}
