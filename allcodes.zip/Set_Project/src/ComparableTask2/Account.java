package ComparableTask2;

public class Account 
{
	private int accno;
	private String acctype;
	private Person p;
	
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAcctype() {
		return acctype;
	}
	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	public Person getP() {
		return p;
	}
	public void setP(Person p) {
		this.p = p;
	}

}
