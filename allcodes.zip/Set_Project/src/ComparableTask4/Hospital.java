package ComparableTask4;

public class Hospital 
{
	private String name;
	private String location;
	private Doctor dr;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Doctor getDr() {
		return dr;
	}
	public void setDr(Doctor dr) {
		this.dr = dr;
	}
	

}
