package ComparableTask4;
import java.util.*;

public class Test 
{
	public static void main(String[] args)
	{
	 Scanner sc = new Scanner(System.in);
	 Set<Hospital> s = new TreeSet<>();
	 
	 for(int i=0; i<5; i++)
	 {
		 
	 }
	}

}
