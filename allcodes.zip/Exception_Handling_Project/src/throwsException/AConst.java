package throwsException;

public class AConst {
  
}
