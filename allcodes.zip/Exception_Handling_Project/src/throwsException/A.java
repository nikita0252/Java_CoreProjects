package throwsException;
import java.io.*;

public class A
{
	public void m1()throws IOException
	{
		
	}
	
	public void m2()
	{
		
	}
	
	public A()
	{
			
	}
}