package throwsException;

public class B extends A {
	
	public void m1()throws ArithmeticException
	{
		
	}
	
	//public void m2()throws ClassNotFound
	{
		
	}
	
	//public B() throws ClassNotFound
	{
		
	}

}
