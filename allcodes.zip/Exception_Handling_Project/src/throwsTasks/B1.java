package throwsTasks;

public class B1 
{
	public void m2()
	{
		System.out.println("B1 m2 start");
		int a=10/2;
		System.out.println(a);
		System.out.println("B1_m2 end");
	}

}
