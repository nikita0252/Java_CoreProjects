package Cons_MethodCalling;

public class Student {
	 int roll_no;
	 String name;
	 String address;
	 long mob_no;
	 
	 public Student(int marks)
	 {
		 System.out.println("Student Data");
		 System.out.println(marks);
	 }

}
