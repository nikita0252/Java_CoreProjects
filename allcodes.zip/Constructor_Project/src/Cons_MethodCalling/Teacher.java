package Cons_MethodCalling;

public class Teacher {
	public Teacher(int tid,String tname)
	{
		System.out.println("ID :"+tid);
		System.out.println("Name :"+tname);
	}

}
