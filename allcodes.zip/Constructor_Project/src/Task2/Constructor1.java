package Task2;

public class Constructor1 {
 
		public Constructor1(int i,int j,String s)
		{
		System.out.println("Constructor int-int-String");
	    }
		public Constructor1(String a,int j,String s)
		{
		System.out.println("Constructor int-int-String");
		}
		public Constructor1(int i,int j,int s)
		{
		System.out.println("Constructor int-int-String");
		}
		public Constructor1(boolean i,boolean j,String s)
		{
		System.out.println("Constructor int-int-String");
		}
		public Constructor1(float i,int j,String s)
		{
		System.out.println("Constructor int-int-String");
		}
		public Constructor1(long i,int j,String s)
		{
		System.out.println("Constructor int-int-String");
		}
		public Constructor1(double i,int j,String s)
		{
		System.out.println("Constructor int-int-String");
		}
		public Constructor1(String i,String j,String s)
		{
		System.out.println("Constructor int-int-String");
		}
		public static void main(String args[])
		{
			Constructor1 c1 = new Constructor1(11,12,"abc");
			Constructor1 c2 = new Constructor1("niki",12,"abc");
			Constructor1 c3 = new Constructor1(11,12,"abc");
			Constructor1 c4 = new Constructor1(11,12,"abc");
			Constructor1 c5 = new Constructor1(11,12,"abc");
			Constructor1 c6 = new Constructor1(11,12,"abc");
			Constructor1 c7 = new Constructor1(11,12,"abc");
			Constructor1 c8 = new Constructor1(11,12,"abc");
			Constructor1 c9 = new Constructor1(11,12,"abc");
			
}
}
