package ConstructorUsingTasks;

public class Manager {
	int id;
	String name,quali,bname;
	float salary;
	
	 public Manager(int id,String name,String quali,String bname,float salary)
	 {
		 this.id=id;
		 this.name=name;
		 this.quali=quali;
		 this.bname=bname;
		 this.salary=salary;
	 }
	

}
