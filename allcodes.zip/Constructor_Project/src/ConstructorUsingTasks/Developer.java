package ConstructorUsingTasks;

public class Developer {
	
	int id;
	String name,projectname;
	float salary;
	char grade;
	
	public Developer(int id,String name,String projectname,float salary,char grade)
	{
		this.id=id;
		this.name=name;
		this.projectname=projectname;
		this.salary=salary;
		this.grade=grade;
	}

}
