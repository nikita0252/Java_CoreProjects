package ConstructorUsingTasks;

public class Patient {
         int id;
         String name,address,disease;
         long mobno;

		public Patient(int id, String name, String address, String disease, long mobno) {
			super();
			this.id = id;
			this.name = name;
			this.address = address;
			this.disease = disease;
			this.mobno = mobno;
		}
}
    
