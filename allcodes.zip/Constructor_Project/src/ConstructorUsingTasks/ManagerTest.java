package ConstructorUsingTasks;

public class ManagerTest {
	public static void main(String args[])

	{
		Manager m = new Manager(102,"aaa","BE Comp","pune",7600.01f);
		System.out.println("Id :"+m.id);
		System.out.println("Name :"+m.name);
		System.out.println("Qualification :"+m.quali);
		System.out.println("Branch Name :"+m.bname);
		System.out.println("Salary :"+m.salary);
				
				
	}
}
