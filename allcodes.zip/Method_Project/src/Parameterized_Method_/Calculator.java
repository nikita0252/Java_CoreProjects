package Parameterized_Method_;

public class Calculator {
	public void add(int i,int j)
	{
		int add = i+j;
		System.out.println("Addition :"+add);
	}
	public void sub(float i,float j)
	{
		float sub = i-j;
		System.out.println("Subtraction :"+sub);
	}
	public void mul(int i,int j)
	{
		int mul  = i*j;
		System.out.println("Subtraction :"+mul);
	}
	public void div(int i,int j)
	{
		int div = i+j;
		System.out.println("Division :"+div);
	}
}
