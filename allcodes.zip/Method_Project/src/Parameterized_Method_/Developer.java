package Parameterized_Method_;

public class Developer {

	int id;
	String name;
	double salary;
	
	
}
