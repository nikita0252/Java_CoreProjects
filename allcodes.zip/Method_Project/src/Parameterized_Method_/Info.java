package Parameterized_Method_;

public class Info {
	public void details()
	{
		Developer d = new Developer();
		d.id=101;
		d.name="abc";
		d.salary=65.65;
	}

}
