package Parameterized_Method_;

public class Test {
 
	public static void main(String args[])
	{
		Info i = new Info();
		i.details();
		Developer d = new Developer();
		System.out.println(d.id);
		System.out.println(d.name);
		System.out.println(d.salary);
		}
}
