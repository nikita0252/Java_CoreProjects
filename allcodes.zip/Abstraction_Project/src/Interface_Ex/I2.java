package Interface_Ex;

public interface I2 extends I1 
{
 int x = 200;
 int y = 300;
 int m3();
 float m4();
}
