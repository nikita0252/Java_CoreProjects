package Interface_Ex;

public interface Connection {
	void commit();
	void rollback();
	

}
