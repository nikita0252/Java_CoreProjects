package Interface_Ex;

public interface I3 extends I,I1,I2
{
 int z = 500;
 boolean m5();
 void m6();
}
