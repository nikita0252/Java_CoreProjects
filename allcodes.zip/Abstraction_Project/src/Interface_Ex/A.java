package Interface_Ex;

public class A implements I1
{
	public void m1()
	{
		System.out.println("M1-I");
	}
	public void m2()
	{
		System.out.println("M2-I");
	}

}
