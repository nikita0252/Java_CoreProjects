package Interface_Ex;

public interface I {
	int i = 100;
	void m1();
	void m2();
}
