package Interface_Ex;

public interface I1 extends I
{
	

}
