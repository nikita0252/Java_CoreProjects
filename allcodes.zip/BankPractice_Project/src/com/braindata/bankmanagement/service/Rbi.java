package com.braindata.bankmanagement.service;

public interface Rbi {

	 public void createAccount();
	 public void depositeMoney();
	 public void withdrawal();
	 public void balanceCheck();
}
