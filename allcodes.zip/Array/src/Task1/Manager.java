package Task1;

public class Manager {
	private int id;
	private String name;
	private long mobno;
	private String department;
	private double salary;
	
	public int getId()
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public long getMobno()
	{
		return mobno;
	}
	public void setMobno(long mobno) 
	{
		this.mobno = mobno;
	}
	public String getDepartment() 
	{
		return department;
	}
	public void setDepartment(String department) 
	{
		this.department = department;
	}
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double salary) 
	{
		this.salary = salary;
	}

}
