package SimpleArray_Ex;

public class DemoArray {
	public static void main(String args[])
	{
		int a []= new int[3];
		a [0]=10;;
		//a [1]=20;
		a [2]=30;
		String s = null;
	
		System.out.println(a[1]);
		System.out.println(s.charAt(2));
	}

}
