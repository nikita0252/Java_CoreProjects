package SimpleArray_Ex;

public class DemoStudentTest {
	public static void main(String args[])
	{
		//DemoStudent s = null;
		//System.out.println(s);
		Object a = new String("ABC");
		String b = (String)a;
		System.out.println(b);
	}
}
