package SimpleArray_Ex;

public class DemoStudent {
	int rollno;
	String name;
	public DemoStudent(int rn, String n) {
		
		rollno = rn;
	    name = n;
	}
	public String toString() {
		return "rollno"+rollno+"name"+name;
	}

}
