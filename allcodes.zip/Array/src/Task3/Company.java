package Task3;

public class Company 
{
	String name;
	String location;
	long mobno;
	Manager man;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public long getMobno() {
		return mobno;
	}
	public void setMobno(long mobno) {
		this.mobno = mobno;
	}
	public Manager getMan() {
		return man;
	}
	public void setMan(Manager man) {
		this.man = man;
	}

}
