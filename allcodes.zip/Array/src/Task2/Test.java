package Task2;

public class Test 
{
	public static void main(String args[])
	{
		Data d = new Data();
		d.instituteData();
		d.ownerData();
		d.addressData();
	}

}
