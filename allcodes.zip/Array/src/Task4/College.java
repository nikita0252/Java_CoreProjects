package Task4;

public class College 
{
	private String name;
	private String Address;
	private long mobno;
	private Principal princ;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public long getMobno() {
		return mobno;
	}
	public void setMobno(long mobno) {
		this.mobno = mobno;
	}
	public Principal getPrinc() {
		return princ;
	}
	public void setPrinc(Principal princ) {
		this.princ = princ;
	}

}
