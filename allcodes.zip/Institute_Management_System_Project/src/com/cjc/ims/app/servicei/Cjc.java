package com.cjc.ims.app.servicei;

public interface Cjc
{
	public void addCourse();
	public void viewCourse();
	public void addFaculty();
	public void viewFaculty();
	public void addBatch();
	public void viewBatch();
	public void addStudent();
	public void viewStudent();

}
